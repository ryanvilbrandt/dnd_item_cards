OTF and TTF: Enchanted Land
Dennis Ludlow 2016 all rights reserved
by Sharkshock 
dennis@sharkshock.net


Welcome to the Enchanted Land where fun has no age limit! This display font captures the magic of classic story book telling with princesses and castles. It features a clean glyph set with many
European accents and diacritics. The whimsical style of the caps flow with consistency and shows up in the numbers and many other marks as well.  All caps are NOT recommended. Use
Enchanted Land for a children's project, book title, or anywhere you'd like a little magic. OTF features like kerning, ordinals, fractions, ligatures, alternates, proportional numbers,
and punctuation are all included in the full version. The demo contains basic latin, numbers, and offers some kerning. 

The complete version is available by $25 donation or purchase of a commercial license. Use the donation link on our homepage and tell us which font you'd like in the notes. Please visit
www.sharkshock.net/license for more information on licensing. Please note that the $25 fee is for PERSONAL use only and does NOT constitute a commercial contract.

This font like my others are free for personal use only as long as this readme file stays intact. For commercial use please contact me at dennis@sharkshock.net to discuss an end user license agreement. You can also visit www.sharkshock.net/license for more info. I also design custom fonts for 
businesses, logos, and many other things. If you'd like to leave me a PayPal donation you can use my email address above. Your generosity will be most appreciated! 

tags: book, children, kids, script, amusement, park, fun, magic, serif, magical, publishing, display, font, typeface, fancy, whimsical, fantasy, enchanting, kid, rides, vacation, characters, Disney, land, logo


visit www.sharkshock.net for more and take a bite out of BORING design!

